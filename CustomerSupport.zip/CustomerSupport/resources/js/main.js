$(document).on('ready', function () {
 $('#CustomerSupportCarousel').carousel({
        interval: false
      });   
});