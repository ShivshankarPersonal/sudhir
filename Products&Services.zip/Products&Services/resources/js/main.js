$(function () {
    $('#nav li a').click(function () {
        //$('#nav li').removeClass();
        $($(this).attr('href')).addClass('active');
    });


    //For mobile device
    $('.tabMob a').click(function (e) {
        e.preventDefault()
        $(this).tab('show')
    });


    //$('.tabMob li:eq(2) a').tab('hide') // Select third tab (0-indexed)
    //$('.tabMob a:last').tab('hide') // Select first tab

    //$('a[href="#navMob4"]').on('show.bs.tab', function (e) {
    //    //debugger;
    //    $('.tabMob').trigger('click');
    //    //$('.tabMob a:last').tab('hide') // Select first tab
    //    //$('.tabMob li:eq(0) a').tab('hide') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(1) a').tab('hide') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(2) a').tab('hide') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(6) a').tab('hide') // Select third tab (0-indexed)
    //});
    //
    //$('.tabMob').on('click', function(){
    //    //$('.tabMob a:last').tab('hide') // Select first tab
    //    $('.tabMob li:eq(0) a').tab('show') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(1) a').tab('hide') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(2) a').tab('hide') // Select third tab (0-indexed)
    //    //$('.tabMob li:eq(6) a').tab('hide') // Select third tab (0-indexed)
    //})
});