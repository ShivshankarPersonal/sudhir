$(document).on('ready', function () {
    var itemsContainer = $('.items');
    var index;
    var itemsLength;
    //For controls alightment
    $('.controls').height($('.item').height());

    function init() {
        var items = itemsContainer.find('.item');
        itemsContainer.append(items.clone());
        itemsLength = items.length;
        index = 0;

        $('.left_control').on('click', goLeft);
        $('.right_control').on('click', goRight);
    }

    function goLeft() {
        index = index - 1;
        updateGallery();
    }

    function goRight() {
        index = index + 1;
        updateGallery();
    }

    function animateLeft(duration, completeFn) {
        var itemWidth = $('.item:first-child').outerWidth();
        var targetLeft = -index * itemWidth;

        itemsContainer.animate({
            animStart: targetLeft,
        }, {
            complete: completeFn,
            duration: duration,
            step: function(now) {
                itemsContainer.css('transform', 'translateX(' + now + 'px)');
            }
        });
    }

    function disableControls() {
        $('.left_control, .right_control').addClass('disabled');
    }

    function enableControls() {
        $('.left_control, .right_control').removeClass('disabled');
    }

    function updateGallery() {
        disableControls();

        //For controls alightment
        $('.controls').height($('.item').height());
        if(index < 0) {
            index = itemsLength;
            animateLeft(0, goLeft);
        } else if(index >= itemsLength) {
            animateLeft(400, function(){
                enableControls();
                index = 0;
                animateLeft(0);
            });
        } else {
            animateLeft(400, function() {
                enableControls();
            });
        }
    }

    init();

    //For mobile devices
    $('#brandCarouselForMobile').carousel({
        interval: false
    });

    $('.brandCarouselMultiImage.carousel .item').each(function () {
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));

        for (var i = 0; i < 3; i++) {
            next = next.next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }

            next.children(':first-child').clone().appendTo($(this));
        }
    });
});