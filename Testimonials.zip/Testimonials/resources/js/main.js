/**
 * Created by Shiv on 16/03/16.
 */
$(document).on('ready', function () {
    //SpotLight  slider (on/off)
    $('#staplesBuAd-Carousel').carousel({
        interval: false
    });
    //Testimonial  slider (on/off)
    $('.staplesBuAd-clusterCirle').carousel({
        interval: false
    });

    //Configuration Option For Showing and Hiding Testimonials
    var hideTestimonials = false;
    var hideUserSpotlight = false;

    if (hideTestimonials) {
        $('#staplesBuAd-testimonialHeading').hide();
        $('#staplesBuAd-testimonialFeedback').hide()
    }
    if (hideUserSpotlight) {
        $('.staplesBuAd-userSpotLightContainer').hide();
    }

    //Configuration Option for Testimonial Carousel Indicator
    var hideTestimonialNavigatorIcons = false;
    if (hideTestimonialNavigatorIcons) {
        $('.staplesBuAd-testimonialCarouselNav').hide();
    }
    //navigation icon align vertically and horizontally
    var slideHeight = $('.staplesBuAd-clusterCirle').height();
    var itemHeight = $('.staplesBuAd-testimonialCarouselItem').find('.col-xs-8').height()
    if (slideHeight) {
        $('.staplesBuAd-navs').height(slideHeight);
    } else {
        $('.staplesBuAd-navs').height(itemHeight);
    }


})