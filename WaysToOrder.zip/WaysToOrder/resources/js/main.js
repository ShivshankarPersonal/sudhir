$(document).on('ready', function () {

    //Configuration Option For Showing and Hiding Testimonials
    var hideWaysToOrderIndividualCta = false;
    var hideWaysToOrderCommonCta = false;

    if (hideWaysToOrderIndividualCta) {
        $('.staplesBuAd-WaysToOrderIndividualFrameCta').hide();
    }
    if (hideWaysToOrderCommonCta) {
        $('.staplesBuAd-WaysToOrderFramesCommonCta').hide();
    }
// Confugure Number of Columns
    var NumberOfColumns = 4;
    var configureWaysToOrderColumns = $('.staplesBuAd-NumberOfCol-WaysToOrder');

    if (NumberOfColumns === 4) {
        $(configureWaysToOrderColumns).addClass('col-lg-3');
        $(configureWaysToOrderColumns).addClass('col-md-3');
        $(configureWaysToOrderColumns).addClass('col-sm-3');
    }
    if (NumberOfColumns === 3) {
        $(configureWaysToOrderColumns).addClass('col-lg-4');
        $(configureWaysToOrderColumns).addClass('col-md-4');
        $(configureWaysToOrderColumns).addClass('col-sm-4');
        $('.staplesBuAd-ColHide').hide();
    }

    //Find height of all the 4 containers - staplesBuAd-WaysToOrderCaptionContainer
    var contrs = $('.staplesBuAd-WaysToOrderCaptionContainer');
    var largestHeight = Math.max(Math.max($(contrs[0]).height(), $(contrs[1]).height()), Math.max($(contrs[2]).height(), $(contrs[3]).height()));
    for (var i = 0; i < contrs.length; i++) {
        $(contrs[i]).height(largestHeight + 40);
    }
})