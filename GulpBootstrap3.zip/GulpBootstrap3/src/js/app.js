//= require ../vendor/jquery/dist/jquery.js
//= require ../vendor/bootstrap-sass-official/assets/javascripts/bootstrap.js
//= require partials/main.js