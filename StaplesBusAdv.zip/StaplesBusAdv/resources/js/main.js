$(document).on('ready', function () {
    var sliderCount = $('.carousel-inner > .item').length;
    if (sliderCount === 1) {
        $('.carousel-indicators').hide();
        $('.left.carousel-control').hide();
        $('.right.carousel-control').hide();
    }

    //Hero Carousel Configure - Speed(ms) or on/off(true/false)
    var configureHero = false;

    if (configureHero === false) {
        $('#myCarousel').carousel({
            interval: configureHero
        });
    } else {
        $('#myCarousel').carousel({
            interval: configureHero
        });
    }
    // Hero-carousel Swipe
         $("#myCarousel").swiperight(function() {$(this).carousel('prev');});  
         $("#myCarousel").swipeleft(function() {$(this).carousel('next');});  
     
    //multi-image carousel starts
    $('#staplesBuAd-Carousel').carousel({
        interval: false
    });

    $('#staplesBuAd-CarouselForSmallDevices').carousel({
        //interval: 5000
        interval: false
    });

    //Configurable Headers and SubHeaders - Alight to Right
    // For 4 Slides we have set the alignment & display values
    var headerCTAPlayButtonConfiguration = [{
        headerRight: false,
        headerCenter: false,
        play: false,
        cta: true
    }, {
        headerRight: false,
        headerCenter: false,
        play: true,
        cta: false
    }, {
        headerRight: false,
        headerCenter: true,
        play: false,
        cta: true
    }, {
        headerRight: false,
        headerCenter: false,
        play: false,
        cta: false
    }];
    function alignHeaderSubHeaderPlayBtnCTABtn(headerCTAPlayButtonConfiguration) {
        for (var i = 0; i < headerCTAPlayButtonConfiguration.length; i++) {
            if (headerCTAPlayButtonConfiguration[i].headerRight === true || headerCTAPlayButtonConfiguration[i].headerCenter === true) {
                if (headerCTAPlayButtonConfiguration[i].headerRight === true) {
                    var header = $('.staplesBuAd-caption-header')[i];
                    var subHeader = $('.staplesBuAd-caption-info')[i];
                    var ctaHero = $('.staplesBuAd-HeroCta')[i];
                    $(header).addClass('staplesBuAd-configurableHeader');
                    $(subHeader).addClass('staplesBuAd-configurableSubHeader');
                    $(ctaHero).addClass('staplesBuAd-configurableCtaToRight');
                } else {
                    var header1 = $('.staplesBuAd-caption-header')[i];
                    var subHeader1 = $('.staplesBuAd-caption-info')[i];
                    var ctaHero1 = $('.staplesBuAd-HeroCta')[i];
                    $(header1).addClass('staplesBuAd-configurableHeaderCenter');
                    $(subHeader1).addClass('staplesBuAd-configurableSubHeaderCenter');
                    $(ctaHero1).addClass('staplesBuAd-configurableCtaToCenter');
                }
            }
            if (headerCTAPlayButtonConfiguration[i].play === false) {
                var playDisplay = $('.staplesBuAd-caption-playButton')[i];
                $(playDisplay).hide();
            }
            if (headerCTAPlayButtonConfiguration[i].cta === false) {
                var ctaDisplay = $('.staplesBuAd-HeroCta')[i];
                $(ctaDisplay).hide();
            }
        }
    }
    alignHeaderSubHeaderPlayBtnCTABtn(headerCTAPlayButtonConfiguration);
});