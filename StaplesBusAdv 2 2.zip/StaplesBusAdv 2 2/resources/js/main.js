$(document).on('ready', function(){
	var sliderCount = $('.carousel-inner > .item').length;
	if(sliderCount === 1){
		$('.carousel-indicators').hide();
		$('.left.carousel-control').hide();
		$('.right.carousel-control').hide();
	}


	//Hero Carousel Speed
	$('#myCarousel').carousel({
		//interval: 6000
		//For removing sliding effer
		interval:false
	});

	//multi-image carousel starts
	$('#staplesBuAd-Carousel').carousel({
		interval: false
	});

	$('#staplesBuAd-CarouselForSmallDevices').carousel({
		//interval: 5000
		interval:false
	});
	//Configurable Headers and SubHeaders - Alight to Right
	// Add which slide's header and sub header you want to be right aligned
	var headerCTAPlayButtonConfiguration = [{
		headerRight:true,
		headerCenter:false,
		play:true,
		cta:true
	},{
		headerRight:false,
		headerCenter:true,
		play:true,
		cta:true
	}, {
		headerRight:false,
		headerCenter:false,
		play:true,
		cta:true
	},{
		headerRight:false,
		headerCenter:false,
		play:true,
		cta:true
	}];

	function alignHeaderSubHeaderPlayBtnCTABtn(headerCTAPlayButtonConfiguration){
		for(var i = 0; i < headerCTAPlayButtonConfiguration.length; i++){
			if(headerCTAPlayButtonConfiguration[i].headerRight === true || headerCTAPlayButtonConfiguration[i].headerCenter === true){
				if(headerCTAPlayButtonConfiguration[i].headerRight === true){
					var header = $('.staplesBuAd-caption-header')[i];
					var subHeader = $('.staplesBuAd-caption-info')[i];
					var ctaHero = $('.staplesBuAd-HeroCta')[i];
					$(header).addClass('staplesBuAd-configurableHeader');
					$(subHeader).addClass('staplesBuAd-configurableSubHeader');
					if(headerCTAPlayButtonConfiguration[i].cta === false){

					}
					$(ctaHero).addClass('staplesBuAd-configurableCtaToRight');
				} else{
					var header1 = $('.staplesBuAd-caption-header')[i];
					var subHeader1 = $('.staplesBuAd-caption-info')[i];
					var ctaHero1 = $('.staplesBuAd-HeroCta')[i];
					$(header1).addClass('staplesBuAd-configurableHeaderCenter');
					$(subHeader1).addClass('staplesBuAd-configurableSubHeaderCenter');
					$(ctaHero1).addClass('staplesBuAd-configurableCtaToCenter');
				}
			}

		}

	}
	alignHeaderSubHeaderPlayBtnCTABtn(headerCTAPlayButtonConfiguration);

	var slideNumberToBeRightAligned = [1,3];

	function alignRightHeaderNSubHeader(slideNumberToBeRightAligned){
		for(var i = 0; i < slideNumberToBeRightAligned.length; i++){
			var header = $('.staplesBuAd-caption-header')[slideNumberToBeRightAligned[i]];
			var subHeader = $('.staplesBuAd-caption-info')[slideNumberToBeRightAligned[i]];
			var ctaHero = $('.staplesBuAd-HeroCta')[slideNumberToBeRightAligned[i]];
			$(header).addClass('staplesBuAd-configurableHeader');
			$(subHeader).addClass('staplesBuAd-configurableSubHeader');
			$(ctaHero).addClass('staplesBuAd-configurableCta');

		}

	}
	//alignRightHeaderNSubHeader(slideNumberToBeRightAligned);

var slideNumberToBeCenterAligned = [2];

	function alignCenterHeaderNSubHeader(slideNumberToBeCenterAligned){
		for(var i = 0; i < slideNumberToBeCenterAligned.length; i++){
			var header1 = $('.staplesBuAd-caption-header')[slideNumberToBeCenterAligned[i]];
			var subHeader1 = $('.staplesBuAd-caption-info')[slideNumberToBeCenterAligned[i]];
			var ctaHero1 = $('.staplesBuAd-HeroCta')[slideNumberToBeCenterAligned[i]];
			$(header1).addClass('staplesBuAd-configurableHeaderCenter');
			$(subHeader1).addClass('staplesBuAd-configurableSubHeaderCenter');
			$(ctaHero1).addClass('staplesBuAd-configurableCtaCenter');

		}

	}
	//alignCenterHeaderNSubHeader(slideNumberToBeCenterAligned);
	//$('.carousel[data-type="multi"] .item').each(function(){
	//	var next = jQuery(this).next();
	//	if (!next.length) {
	//		next = jQuery(this).siblings(':first');
	//	}
	//	next.children(':first-child').clone().appendTo(jQuery(this));
    //
	//	for (var i=0;i<2;i++) {
	//		next=next.next();
	//		if (!next.length) {
	//			next = jQuery(this).siblings(':first');
	//		}
	//		next.children(':first-child').clone().appendTo($(this));
	//	}
	//});
	//multi-image carousel ends

});