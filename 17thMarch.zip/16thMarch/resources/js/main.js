/**
 * Created by Shiv on 16/03/16.
 */
$(document).on('ready', function(){
    //multi-image carousel starts
    $('#staplesBuAd-Carousel').carousel({
        interval: false
    });
    $('#staplesBuAd-clusterCirle').carousel({
        interval: 7000
    });
    $('#staplesBuAd-clusterAvatar').carousel({
        interval: 7000
    });

    //Configuration Option For Showing and Hiding Testimonials
    var hideTestimonials = false;
    var hideUserSpotlight = false;
    
    if(hideTestimonials){
        $('#staplesBuAd-testimonialHeading').hide();
        $('#staplesBuAd-testimonialFeedback').hide()
    }
    if(hideUserSpotlight){
        $('.staplesBuAd-userSpotLightContainer').hide();
    }
})